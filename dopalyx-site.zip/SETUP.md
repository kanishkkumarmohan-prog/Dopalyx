# Turn on Google sign-in for Dopalyx (optional)

Without this, Dopalyx still works and saves everything on the device. Take care with these steps, because they involve accounts and people's health-related data.

1. Go to https://console.firebase.google.com and click **Add project**.
2. **Build > Authentication > Get started > Sign-in method > Google > Enable.** Pick a support email, then Save.
3. **Authentication > Settings > Authorized domains > Add domain.** Add the website address where Dopalyx is hosted (for example `yoursite.netlify.app`).
4. **Build > Firestore Database > Create database.** Choose production mode.
5. In Firestore, open the **Rules** tab, paste the contents of `firestore.rules`, and click **Publish**. This makes sure each person can only read their own data.
6. **Project settings (gear icon) > Your apps > Web (</>)**. Register an app and copy the `firebaseConfig` values.
7. In `index.html`, find `const FIREBASE_CONFIG=null;` and replace `null` with your config, for example:
   `const FIREBASE_CONFIG={apiKey:"...",authDomain:"...",projectId:"...",appId:"..."};`
   (The web config is not secret. The security rules in step 5 are what protect the data.)
8. Upload `index.html` again.

Before going live: update your Privacy policy contact email, and think about whether you are comfortable storing health-related information for other people. Check the privacy laws that apply where your users live.


## Professional checklist (added)

- **Support email:** open `index.html`, find `const SUPPORT_EMAIL=''` and put your real address (for example support@yourdomain.com). The Support page then shows it.
- **Custom domain:** Netlify > Domain management > Add a domain. HTTPS is automatic.
- **Staging site:** Netlify > Site configuration > Build & deploy > Branches and deploy previews. Turn on branch deploys, put new work on a `staging` branch, and check it before merging.
- **Error monitoring (optional):** create a free Sentry project, then add its browser script tag in `<head>` and add `https://browser.sentry-cdn.com` to `script-src` and your Sentry ingest host to `connect-src` in `netlify.toml`.
- **Analytics (optional):** Plausible: add its script tag and add `https://plausible.io` to `script-src` and `connect-src`. Without those CSP edits the browser will block them.
- **Content-Security-Policy:** set in `netlify.toml`. If you add any new outside service, add its host there too.
- **Lighthouse:** in Chrome DevTools > Lighthouse, run on the live site (mobile) and check Performance, Accessibility, Best practices and SEO.

