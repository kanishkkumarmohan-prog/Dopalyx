# Putting Dopalyx in the App Store and Google Play (Capacitor)

This wraps the same website in a real phone app. These files were not run on a phone from here, so treat this as a starting point.

1. Install Node.js, then in this folder run `npm install`.
2. `npx cap add android` and/or `npx cap add ios` (iOS needs a Mac with Xcode).
3. `npm run sync` whenever you change the website.
4. `npx cap open android` or `npx cap open ios`, then run it on a real phone.
5. Check on a real phone: the motion sensor, microphone (dictation) and notifications. Android WebView and iOS may ask for permission text. For iOS add `NSMicrophoneUsageDescription` and `NSMotionUsageDescription` to Info.plist.
6. Store listing needs: a privacy policy URL (the Privacy page in the app, hosted at your Netlify address), the "not a medical device" wording, and screenshots.
7. Apple and Google both review health apps closely. Keep the claim "educational wellness tool, not a medical device".

Things a wrapper adds later: background reminders (Capacitor Local Notifications plugin) and Apple Health / Health Connect (separate plugins). Neither is wired up yet.

Accounts: Apple Developer is about $99 per year, Google Play is a one-time $25.
