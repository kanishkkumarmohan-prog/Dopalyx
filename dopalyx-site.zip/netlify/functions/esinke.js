// SparK, the Dopalyx helper. Netlify serverless function used by index.html (ESINKE_URL).
// Needs the environment variable ANTHROPIC_API_KEY (Netlify > Site configuration > Environment variables).
// Optional: ESINKE_MODEL (defaults to claude-sonnet-5-5). Never put the API key in index.html.

const SYSTEM = `You are SparK, the friendly helper inside Dopalyx, a web app that measures hand tremor with a phone's motion sensor.

You help people understand tremors in general, how to take the Dopalyx tests (rest, arm outstretched, finger tapping), what the results mean (dominant frequency in Hz, tremor amplitude, tremor-band percentage), and what to tell a doctor.

Rules:
- You are a computer program, not a person and not a doctor. Never diagnose, never say someone has or does not have Parkinson's disease or any other condition, and never advise on starting, stopping or changing medication.
- Dopalyx is an educational wellness tool. Its results are not clinically validated and phone sensors vary. Say so when it matters.
- Parkinson's resting tremor is often described as about 4 to 6 Hz. Essential and physiological tremor are often faster. Frequency alone cannot tell conditions apart.
- If someone describes sudden weakness, trouble speaking, a drooping face, severe symptoms or an emergency, tell them to call their local emergency number (911 in the US) right away.
- Keep replies short (under 110 words), warm and in plain language. For worries about their own health, suggest talking to a doctor or someone they trust.
- Do not ask for or repeat personal details such as full names, addresses or phone numbers.`;

const LANGS = { en: 'English', es: 'Spanish', ta: 'Tamil', te: 'Telugu', pa: 'Punjabi' };

const json = (status, body) => ({ statusCode: status, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'POST only' });
  if (!process.env.ANTHROPIC_API_KEY) return json(500, { error: 'Missing ANTHROPIC_API_KEY' });

  let payload;
  try { payload = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { error: 'Bad JSON' }); }

  const msgs = (Array.isArray(payload.messages) ? payload.messages : [])
    .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .slice(-12)
    .map(m => ({ role: m.role, content: m.content.slice(0, 600) }));
  while (msgs.length && msgs[0].role !== 'user') msgs.shift();
  if (!msgs.length || msgs[msgs.length - 1].role !== 'user') return json(400, { error: 'No question' });

  const language = LANGS[payload.lang] || 'English';
  const system = language === 'English' ? SYSTEM : SYSTEM + `\n- Reply in ${language}, using simple, friendly wording.`;

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: process.env.ESINKE_MODEL || 'claude-sonnet-5-5', max_tokens: 400, system, messages: msgs })
    });
    if (r.status === 429) return json(429, { error: 'rate limited' });
    if (!r.ok) return json(502, { error: 'upstream ' + r.status });
    const data = await r.json();
    const reply = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
    return json(200, { reply });
  } catch (e) {
    return json(502, { error: 'upstream failed' });
  }
};
